import cv2
import numpy as np

# خواندن تصویر
image = cv2.imread('shoes.jpg')
original = image.copy()  # کپی از تصویر اصلی

# پیش‌پردازش
gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) #tabdil tasvir rangi be siyahosefid
blur = cv2.GaussianBlur(gray, (5,5), 0)  #mahv kardan tasvir baraye kahesh noise
edges = cv2.Canny(blur, 50, 150)  #tashkhis labe ha dar tasvir 

# پیدا کردن کانتورها
contours, _ = cv2.findContours(edges, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

# شمارش و رسم کانتورهای معتبر برای تشخیص کفش 
shoe_count = 0
for cnt in contours:
    area = cv2.contourArea(cnt) # محاسبه مساحت هر کانتور 
    if area > 500:  # فیلتر کردن کانتور های کوچک که احتمالا نویز هستن
        approx = cv2.approxPolyDP(cnt, 0.02*cv2.arcLength(cnt, True), True)  # ساده سازی کانتور ها به چندضلعی ها 
        if len(approx) >=4: # فقط اشیایی با 4 گوشه یا بیشتر بررسی شوند 
            shoe_count += 1
            cv2.drawContours(image, [cnt], -1, (0,255,0), 2) #رسم کانتور با رنگ سبز 
            
            # محاسبه مرکز برای نوشتن شماره
            M = cv2.moments(cnt)   # محاسبه مرکز هندسی کانتور 
            if M["m00"] != 0:
                cX = int(M["m10"] / M["m00"])
                cY = int(M["m01"] / M["m00"])
                cv2.putText(image, f"Shoe {shoe_count}", (cX-40, cY),    #نوشتن شماره کفش در مرکز ان با رنگ ابی 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,0,0), 2)


result = np.hstack((original, image))  #   کنار هم قرار دادن تصاویر به صورت افقی 

#نمایش پنجره نتیجه ا
cv2.namedWindow('نتایج تشخیص کفش', cv2.WINDOW_NORMAL)
cv2.resizeWindow('نتایج تشخیص کفش', 1200, 600)
cv2.imshow('نتایج تشخیص کفش', result) #نمایش تصویر نهایی 

# متن نتایج در کنسول
print("\n" + "="*50)
print(f"🔍 تعداد کفش‌های تشخیص داده شده: {shoe_count} عدد")
print("="*50 + "\n")

cv2.waitKey(0)
cv2.destroyAllWindows()

 #ذخیره نتیجه
cv2.imwrite('result.jpg', result)
print("✅ تصویر نتیجه در فایل 'result.jpg' ذخیره شد.")
